package com.example.android.movies;

/**
 * Created by Abdulrhman on 01/12/2016.
 */
public interface handlerCallback {

    /**
     * notify MainActivity with the new selected item
     */
    public void onItemSelected(ItemsClass currentObject);
}
